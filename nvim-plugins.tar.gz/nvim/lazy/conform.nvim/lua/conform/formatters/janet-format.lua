--@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/janet-lang/spork",
    description = "A formatter for Janet code.",
  },
  command = "janet-format",
  stdin = true,
}
