---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://www.gnu.org/software/indent/",
    description = "GNU Indent.",
  },
  command = "indent",
  stdin = true,
}
