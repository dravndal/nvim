text

```lua
local foo = "bar"
local bar = 2
```
